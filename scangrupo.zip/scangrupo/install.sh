apt udpdate
apt upgrade -y
pkg install python -y
pip install http.client
pip install requests
pip install pyfiglet
pip install rich